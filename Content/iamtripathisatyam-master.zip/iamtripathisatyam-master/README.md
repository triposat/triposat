![Student|Programmer|Motivator|Designer](https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/gtss.png)
<p align="center">
<img src="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/github.gif" width="200px" height="200px">
 </p>
 
### <h1 align="center">Hi there, I'm Satyam Tripathi <img src="https://raw.githubusercontent.com/ABSphreak/ABSphreak/master/gifs/Hi.gif" width="50px"><h1/>
## <h3 align="center">I'm a 2nd Year CSE Student, Programmer, Designer, Motivator!<h3/>
 
- ✌️ Currently Pursuing **`B.Tech From PSIT Kanpur`**
- 🔭 **I’m Currently Working on :**
- [x] ![](https://img.shields.io/badge/Python-%7C-0%2C%2022%2C%20100)  
- [x] ![](https://img.shields.io/badge/Canva_Designing-%7C-orange)
- [x] ![](https://img.shields.io/badge/MicroSoft_Word-%7C-blue)
- [x] ![](https://img.shields.io/badge/Data_Structure-%7C-yellow)
- 🌱 I’m currently learning **`Programming and Designing!`** ✌️✌️
- 👯 I’m looking to Collaborate with other Content Creators
- 🥅 2020 Goals: Become Expert in **`PYTHON and DESIGNING`** 🎯🎯
- ✔️ Fun fact : I love **`Listening to Music and Doing Yoga!`**
- 🎯 Future Goal : **Become Expert in :** 
- [x] ![](https://img.shields.io/badge/Python-%7C-0%2C%2022%2C%20100) ![](https://img.shields.io/badge/Python_Django-%7C-blue) ![](https://img.shields.io/badge/Python_Flask-%7C-brown)
- [x] ![](https://img.shields.io/badge/Python_Tkinter-%7C-violet) ![](https://img.shields.io/badge/App_Designing-%7C-indigo) ![](https://img.shields.io/badge/Ethical_Hacking-%7C-yellow) 
- [x] ![](https://img.shields.io/badge/DS&Algo-%7C-pink) ![](https://img.shields.io/badge/Dart-%7C-blue) ![](https://img.shields.io/badge/Flutter-%7C-yellow) ![](https://img.shields.io/badge/Rive-%7C-pink)<br/>
### <h1 align="center">**My Repositories**<h1/>
 <body>
    <div class="img1">
     <p align='center'>
 <a href="https://github.com/Iamtripathisatyam/Python-Projects" target="_blank"><img src="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/try-removebg-preview.png" alt="Repository" width="130" height="135"></a><a href="https://github.com/Iamtripathisatyam/Python-Hackerrank-Solutions"><img src="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/awes-removebg-preview.png" width="130" height="135"></a>
<a href="https://github.com/Iamtripathisatyam/C-Programming-Projects"><img src="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/Purple_and_White_Gaming_Logoaao-removebg-preview.png" width="140" height="145"></a><a href="https://github.com/Iamtripathisatyam/C-Programs"><img src="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/psi-removebg-preview.png" width="130" height="135"></a><a href="https://github.com/Iamtripathisatyam/Data-Structure-Programs"><img src="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/go-removebg-preview.png" width="130" height="135"></a>
<p/>
</div>
</body>
 
 ### <h1 align="center">Feel Free to **`Contact Me`** : <h1/>
 <body>
    <div class="img1">
     <p align='center'>
 <a href="https://www.linkedin.com/in/Satyam-Tripathi-536b561b1" target="_blank"><img src="https://icons.iconarchive.com/icons/limav/flat-gradient-social/48/Linkedin-icon.png" alt="Linkedin"></a> <a href="https://www.hackerrank.com/tripathiishere" target="_blank"><img src="https://upload.wikimedia.org/wikipedia/commons/6/65/HackerRank_logo.png" alt="Linkedin" width="64" height="64"></a> 
 <a href="mailto:thingstesting2020@gmail.com" target="_blank"><img src="https://icons.iconarchive.com/icons/wwalczyszyn/android-style-honeycomb/48/GMail-icon.png" alt="Email"></a>
  <p/>
</div>
</body>
   <br/>
 
### <h1 align="center">SKILLS : <h1/>
 
 <body>
    <div class="img1">
     <p align='center'>
 <a href="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/Percent.png" target="_blank"><img src="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/Percent.png" alt="Repository" width="400" height="350"></a>
<p/>
</div>
</body>
<br/>

### <h1 align="center">Improving Myself Everyday With :  <h1/>
 
 <body>
    <div class="img1">
     <p align='center'>
 <a href="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/Focus.png" target="_blank"><img src="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/Focus.png" alt="Repository" width="400" height="350"></a>
<p/>
</div>
</body>
<br/>
<h1 align="center">Languages and Tools :<h1/>

![](https://icons.iconarchive.com/icons/papirus-team/papirus-apps/72/python-icon.png)
![](https://icons.iconarchive.com/icons/mattahan/umicons/72/Letter-C-icon.png)
![](https://icons.iconarchive.com/icons/graphics-vibe/developer/72/html-5-icon.png)
![](https://icons.iconarchive.com/icons/papirus-team/papirus-apps/72/pycharm-icon.png)
![](https://icons.iconarchive.com/icons/benjigarner/softdimension/72/MS-Word-2-icon.png)
![](https://icons.iconarchive.com/icons/hopstarter/sleek-xp-software/72/Dev-icon.png)
![](https://icons.iconarchive.com/icons/rud3boy/mac-apps/72/ps-icon.png)
![](https://icons.iconarchive.com/icons/papirus-team/papirus-apps/72/visual-studio-code-icon.png)

<p align="center">
<img src="https://github-readme-stats.vercel.app/api?username=Iamtripathisatyam&show_icons=true&theme=dracula" alt="Iamtripathisatyam" />
</p>
<p align="center">
<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Iamtripathisatyam&theme=dracula&layout=compact" alt="Iamtripathisatyam" />
</p>
<p align="center">
<img src="https://github.com/Iamtripathisatyam/iamtripathisatyam/blob/master/TOH.gif" alt="HTML5 Icon" align='center' style="float:center;width:128px;height:128px;">
 </p>
